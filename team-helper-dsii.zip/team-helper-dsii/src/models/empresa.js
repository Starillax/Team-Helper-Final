const { dbcon } = require("../config/connection-db");

class Empresa {
    constructor(id, nome) {
        this.id = id;
        this.nome = nome;
    }
}

// DAO = DATA ACCESS OBJECT
class EmpresaDAO {

    static async cadastrarEmpresa(empresa) {

        const sql = 'INSERT INTO empresa (nome) VALUES ($1);';
        const values = [empresa.nome];

        try {
            await dbcon.query(sql, values);
            console.log('CADASTRO DE EMPRESA BEM-SUCEDIDO!');
        } catch (error) {
            console.log('NÃO FOI POSSÍVEL CADASTRAR O EMPRESA');
            console.log({ error });
        }
        
    }

    static async encontrarEmpresas() {

        const sql = 'SELECT * FROM empresa;';

        const result = await dbcon.query(sql);
        const empresas = result.rows;

        return empresas;

    }

    static async encontrarNomeDaEmpresa(empresa_id) {

        const sql = 'SELECT nome FROM empresa where id = $1;';

        const result = await dbcon.query(sql, [empresa_id]);
        const empresa = result.rows[0];

        return empresa;

    }

    static async encontrarTimesDaEmpresa(empresa_id) {

        const sql = 'SELECT * FROM time where empresa = $1;';

        const result = await dbcon.query(sql, [empresa_id]);
        const empresa = result.rows;

        return empresa;

    }

    static async encontrarMembrosDaEmpresa(empresa_id) {

        const sql1 = 'SELECT usuario.email AS usuario_email, usuario.nome AS usuario_nome, usuario.empresa AS usuario_empresa, time.id AS time_id, time.nome as time_nome FROM usuario JOIN timeusuario ON timeusuario.usuario = usuario.email JOIN time ON time.id = timeusuario.time WHERE usuario.empresa = $1 ORDER BY time.nome;';

        const result1 = await dbcon.query(sql1, [empresa_id]);

        const sql2 = 'SELECT usuario.email AS usuario_email, usuario.nome AS usuario_nome, usuario.empresa AS usuario_empresa, time.id AS time_id, time.nome as time_nome FROM usuario JOIN time ON time.admin = usuario.email WHERE usuario.empresa = $1 ORDER BY time.nome;';

        const result2 = await dbcon.query(sql2, [empresa_id]);

        const results = [].concat(result1.rows, result2.rows);

        return results;

    }

}

module.exports = {
    Empresa,
    EmpresaDAO
};