const { dbcon } = require('../config/connection-db');
const { Empresa, EmpresaDAO } = require('../models/empresa');

class EmpresasController {

    async mostrarCadastro(req, res) {
        return res.render('empresa_form', {user : req.session.user});
    }

    async cadastrar(req, res) {
        
        const empresaBody = {
            nome: req.body.nome
        }
        
        const empresa = new Empresa(null, empresaBody.nome);
        await EmpresaDAO.cadastrarEmpresa(empresa);

        return res.redirect('/');

    }

    async mostrarTimesDaEmpresa(req, res) {

        const { empresa_id } = req.params;
        let times_empresa = [];

        const result1 = await EmpresaDAO.encontrarNomeDaEmpresa(empresa_id);
        const result2 = await EmpresaDAO.encontrarTimesDaEmpresa(empresa_id);
        const result3 = await EmpresaDAO.encontrarMembrosDaEmpresa(empresa_id);

        for (const time of result2) {
            const membros = result3.filter((membro) =>
                membro.time_id == time.id
            )
            times_empresa.push({ ...time, membros })
        }

        return res.render('empresa_membros', {user: req.session.user, empresa_nome: result1, times: times_empresa});
    }

}

module.exports = EmpresasController;